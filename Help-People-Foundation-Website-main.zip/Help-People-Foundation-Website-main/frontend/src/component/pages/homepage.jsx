import React from 'react';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import { Link } from 'react-router-dom';

const Homepage = () => {
  return (
    <div className="min-h-screen bg-gray-50">

      {/* Hero Section with Mission Statement */}
      <section className="bg-blue-700 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Helping those in need, one step at a time.</h1>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            We're committed to providing food, shelter, and support to vulnerable communities around the world.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/donate">
              <button className="bg-white text-blue-700 px-6 py-3 rounded-md font-semibold hover:bg-gray-100 transition">
                Donate Now
              </button>
            </Link>
            <Link to="/volunteer">
            <button className="bg-transparent border-2 border-white px-6 py-3 rounded-md font-semibold hover:bg-white hover:text-blue-700 transition">
              Volunteer
            </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Impact Carousel */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Our Impact in Action</h2>

          <div className="max-w-4xl mx-auto">
            <Carousel
              showArrows={true}
              infiniteLoop={true}
              showThumbs={false}
              autoPlay={true}
              interval={5000}
              showStatus={false}
            >
              <div>
                <img
                  src="https://images.unsplash.com/photo-1601597111158-2fceff292cdc?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
                  alt="Food distribution"
                  className="h-96 object-cover"
                />
                <div className="legend bg-blue-600 bg-opacity-80 p-4">
                  <h3 className="text-xl font-bold">Food Distribution</h3>
                  <p>Over 10,000 meals served monthly to families in need</p>
                </div>
              </div>
              <div>
                <img
                  src="https://images.unsplash.com/photo-1513694203232-719a280e022f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
                  alt="Shelter aid"
                  className="h-96 object-cover"
                />
                <div className="legend bg-blue-600 bg-opacity-80 p-4">
                  <h3 className="text-xl font-bold">Shelter Aid</h3>
                  <p>Providing safe housing for 500+ homeless individuals annually</p>
                </div>
              </div>
              <div>
                <img
                  src="https://images.unsplash.com/photo-1521791055366-0d553872125f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
                  alt="Education programs"
                  className="h-96 object-cover"
                />
                <div className="legend bg-blue-600 bg-opacity-80 p-4">
                  <h3 className="text-xl font-bold">Education Programs</h3>
                  <p>Supporting 200+ children with access to quality education</p>
                </div>
              </div>
            </Carousel>
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-8 text-gray-800">Join Us in Making a Difference</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-blue-600 text-5xl mb-4">💰</div>
              <h3 className="text-xl font-semibold mb-3">Donate</h3>
              <p className="text-gray-600 mb-4">Your financial support helps us reach more people in need.</p>
              <Link to="/donate">
              <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition">
                Donate Now
              </button>
              </Link>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-blue-600 text-5xl mb-4">👐</div>
              <h3 className="text-xl font-semibold mb-3">Volunteer</h3>
              <p className="text-gray-600 mb-4">Give your time and skills to directly impact lives.</p>
              <Link to="/volunteer">
              <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition">
                Volunteer
              </button>
              </Link>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-blue-600 text-5xl mb-4">📢</div>
              <h3 className="text-xl font-semibold mb-3">Post a Blog</h3>
              <p className="text-gray-600 mb-4">Share your thought to make a impact.</p>
              <Link to="/blog">
              <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition">
                Post a Blog
              </button>
              </Link>
            </div>
          </div>
        </div>
      </section>


    </div>
  );
};

export default Homepage;