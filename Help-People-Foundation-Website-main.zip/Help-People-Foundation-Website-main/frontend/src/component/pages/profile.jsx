import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const ProfilePage = () => {
    const [isLoading, setIsLoading] = useState(false);
    const [isLoadingDonations, setIsLoadingDonations] = useState(false);
    const [userBio, setUserBio] = useState('');
    const [donations, setDonations] = useState([]);
    const navigate = useNavigate();

    // Safely get user data from localStorage
    const getUserData = () => {
        try {
            const firstName = localStorage.getItem("firstname") || '';
            const lastName = localStorage.getItem("lastname") || '';
            const email = localStorage.getItem("email") || '';
            
            return {
                name: `${firstName} ${lastName}`.trim(),
                email: email
            };
        } catch (error) {
            console.error("Error accessing localStorage:", error);
            return { name: '', email: '' };
        }
    };

    const user = getUserData();

    const getUserBio = useCallback(async () => {
        try {
            setIsLoading(true);
            const token = localStorage.getItem('token');
            if (!token) {
                navigate('/login');
                return;
            }
            const response = await axios.get('http://localhost:5000/api/user/bio', {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            setUserBio(response.data.bio || 'No bio available');
        } catch (error) {
            console.error('Error fetching user data:', error);
            setUserBio('Error loading bio');
        } finally {
            setIsLoading(false);
        }   
    }, [navigate]);

    const getDonationHistory = useCallback(async () => {
    try {
        setIsLoadingDonations(true);
        const token = localStorage.getItem('token');
        if (!token || !user.email) {
            return;
        }
        
        const response = await axios.get(`http://localhost:5000/api/donations`, {
            headers: {
                Authorization: `Bearer ${token}`
            },
            params: {
                email: user.email
            }
        });
        
        setDonations(response.data || []);
    } catch (error) {
        if (error.response?.status === 401 || error.response?.status === 403) {
            // Token expired or invalid
            localStorage.removeItem('token');
            navigate('/login');
        } else {
            console.error('Error fetching donation history:', error);
            setDonations([]);
        }
    } finally {
        setIsLoadingDonations(false); //calling function to set loading state
    }
}, [user.email, navigate]);

    useEffect(() => {
        if (user.name && user.email) {
            getUserBio();
            getDonationHistory();
        }
    }, [user.name, user.email, getUserBio, getDonationHistory]);


    if (!user.name || !user.email) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <h1 className="text-2xl font-bold">Profile Not Found</h1>
                    <p className="mt-4">Please <Link to="/login" className="text-blue-500">login</Link> to view your profile.</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-100 p-4 py-8">
            <div className="max-w-4xl mx-auto space-y-6">
                {/* Profile Card */}
                <div className="bg-white rounded-lg shadow-md p-6">
                    <div className="flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-6">
                        <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center">
                            <span className="text-4xl font-medium text-gray-600">
                                {user.name.charAt(0).toUpperCase()}
                            </span>
                        </div>
                        
                        <div className="flex-1">
                            <h2 className="text-2xl font-bold text-gray-800">{user.name}</h2>
                            <p className="text-gray-600">{user.email}</p>
                            
                            <div className="mt-4">
                                <h3 className="font-semibold text-gray-700">About</h3>
                                {isLoading ? (
                                    <p className="text-gray-600 mt-1">Loading bio...</p>
                                ) : (
                                    <p className="text-gray-600 mt-1">
                                        {userBio || 'No bio available'}
                                    </p>
                                )}
                            </div>
                            
                            <div className="mt-6">
                                <Link 
                                    to="/settings" 
                                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                                >
                                    Edit Profile
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Donation History */}
                <div className="bg-white rounded-lg shadow-md p-6">
                    <h2 className="text-xl font-bold text-gray-800 mb-4">Donation History</h2>
                    
                    {isLoadingDonations ? (
                        <p className="text-gray-600">Loading donation history...</p>
                    ) : donations.length === 0 ? (
                        <p className="text-gray-600">No donations found</p>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-gray-200">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Frequency</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Payment Method</th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-gray-200">
                                    {donations.map((donation) => (
                                        <tr key={donation.id}>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                {new Date(donation.created_at).toLocaleDateString()}
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                                Rs. {donation.amount}
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">
                                                {donation.frequency.replace('-', ' ')}
                                            </td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                **** **** **** {donation.card_last_four}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ProfilePage;