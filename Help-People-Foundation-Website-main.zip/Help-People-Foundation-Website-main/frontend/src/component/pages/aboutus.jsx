import React from 'react';

const About = () => {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Header Section */}
      <div className="text-center my-8">
        <h1 className="text-5xl font-extrabold mb-4 text-indigo-600 tracking-wide ">
          About Us
        </h1>
        <p className="text-gray-600 text-lg">
          Learn more about our mission, vision, and the compassionate team behind the Kandoo Himalayan Foundation.
        </p>
      </div>
      <hr className="border-0 h-px bg-indigo-300 my-4" />

      {/* About Content */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-10">
        {/* Mission Card */}
        <div className="bg-white rounded-lg shadow-lg transform hover:-translate-y-2 transition-transform duration-300">
          <div className="p-6 text-center">
            <h3 className="text-2xl font-bold mb-4 text-indigo-500">Our Mission</h3>
            <p className="text-gray-700">
              At Kandoo Himalayan Foundation, our mission is to uplift underprivileged communities by providing access to basic needs such as food, shelter, education, and healthcare. We aim to create opportunities for a better life, filled with hope and dignity.
            </p>
          </div>
        </div>

        {/* Vision Card */}
        <div className="bg-white rounded-lg shadow-lg transform hover:-translate-y-2 transition-transform duration-300">
          <div className="p-6 text-center">
            <h3 className="text-2xl font-bold mb-4 text-indigo-500">Our Vision</h3>
            <p className="text-gray-700">
              We envision a world where no one is left behind due to poverty or lack of resources. Through our efforts, we strive to build a compassionate society where everyone has equal access to the essentials of life and the opportunity to thrive.
            </p>
          </div>
        </div>

        {/* Team Card */}
        <div className="bg-white rounded-lg shadow-lg transform hover:-translate-y-2 transition-transform duration-300">
          <div className="p-6 text-center">
            <h3 className="text-2xl font-bold mb-4 text-indigo-500">Our Team</h3>
            <p className="text-gray-700">
              Our team is made up of caring volunteers, donors, and social workers united by a common goal — to serve those in need. With empathy at our core, we work tirelessly to provide sustainable support and bring positive change to the lives of the poor and vulnerable.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
