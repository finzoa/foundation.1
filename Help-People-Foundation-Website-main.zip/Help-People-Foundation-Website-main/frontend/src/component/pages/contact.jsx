import React, { useState } from "react";
import office1 from "../../images/office1.jpg";
import office2 from "../../images/office2.jpg";
import office3 from "../../images/office3.jpg";
import '@fortawesome/fontawesome-free/css/all.min.css';

const images = [
  { src: office1, alt: "Office Image 1" },
  { src: office2, alt: "Office Image 2" },
  { src: office3, alt: "Office Image 3" },
];

const Contact = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextImage = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
  };

  const prevImage = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-white to-blue-200 px-4 py-12">
      {/* Header Section */}
      <div className="text-center mb-10">
        <h1 className="text-5xl font-extrabold text-indigo-700 mb-2">Contact Us</h1>
        <p className="text-gray-600 text-lg">We're here to help! Reach out to us anytime.</p>
      </div>

      {/* Main Content */}
      <div className="flex flex-col lg:flex-row justify-center gap-10 max-w-6xl mx-auto">
        {/* Left Section - Carousel & Contact Info */}
        <div className="w-full lg:w-2/3 space-y-8">
          {/* Image Carousel */}
          <div className="relative w-full aspect-[4/3] bg-gray-100 rounded-lg shadow-xl overflow-hidden">
            {images.map((image, index) => (
              <div
                key={index}
                className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
                  index === currentIndex ? "opacity-100 z-10" : "opacity-0 z-0"
                }`}
              >
                <img
                  src={image.src}
                  alt={image.alt}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}

            {/* Carousel Controls */}
            <button
              onClick={prevImage}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-indigo-600 text-white p-2 rounded-full hover:bg-indigo-800 shadow"
              aria-label="Previous"
            >
              &#10094;
            </button>
            <button
              onClick={nextImage}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-indigo-600 text-white p-2 rounded-full hover:bg-indigo-800 shadow"
              aria-label="Next"
            >
              &#10095;
            </button>

            {/* Dots */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
              {images.map((_, idx) => (
                <span
                  key={idx}
                  className={`w-3 h-3 rounded-full ${
                    idx === currentIndex ? "bg-indigo-600" : "bg-white border"
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Contact Information */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold text-indigo-700 mb-4">Get in Touch</h2>
            <ul className="space-y-4 text-gray-700">
              <li>
                <strong>Email:</strong>{" "}
                <a href="mailto:finzobhote@gmail.com" className="text-indigo-600 hover:underline">
                  finzobhote@gmail.com
                </a>
              </li>
              <li>
                <strong>Phone:</strong>{" "}
                <a href="tel:+977981020304050" className="text-indigo-600 hover:underline">
                  +977 981020304050
                </a>
              </li>
              <li>
                <strong>Address:</strong> Kalanki, Kathmandu, Nepal
              </li>
            </ul>
          </div>
        </div>

        {/* Right Section - Follow Us */}
        {/* Follow Us Section */}
        <div className="w-full md:w-2/3 lg:w-1/3">
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <h2 className="text-2xl font-semibold text-indigo-600 mb-10 text-center underline">
              Follow Us
            </h2>
            <div className="flex justify-center space-x-6">
              <a
                href="https://www.facebook.com/profile.php?id=61552798688578"
                className="text-indigo-600 hover:text-indigo-800"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i className="fab fa-facebook-f fa-2x"></i>
              </a>
              <a
                href="https://x.com/Surendr48649414"
                className="text-indigo-600 hover:text-indigo-800"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i className="fab fa-twitter fa-2x"></i>
              </a>
              <a
                href="https://www.instagram.com/surendra___g?igsh=MTJpaDg4NGp4Z3dpbA=="
                className="text-indigo-600 hover:text-indigo-800"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i className="fab fa-instagram fa-2x"></i>
              </a>
              <a
                href="https://www.linkedin.com/in/surendra-giri-4823b830b/"
                className="text-indigo-600 hover:text-indigo-800"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i className="fab fa-linkedin-in fa-2x"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
