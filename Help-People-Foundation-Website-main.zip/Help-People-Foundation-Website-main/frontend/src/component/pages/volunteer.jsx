import React, { useState, useEffect } from 'react';

const VolunteerPage = () => {
  const [opportunities, setOpportunities] = useState([]);
  const [filteredOpportunities, setFilteredOpportunities] = useState([]);
  const [filters, setFilters] = useState({
    category: '',
    time: '',
    location: ''
  });
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    interest: '',
    availability: '',
    experience: '',
    agree: false
  });
  const [submitted, setSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  // Extract unique categories, times, and locations for filter options
  const categories = [...new Set(opportunities.map(opp => opp.title))];
  const times = [...new Set(opportunities.map(opp => opp.time))];
  const locations = [...new Set(opportunities.map(opp => opp.location))];

  useEffect(() => {
    const fetchOpportunities = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await fetch('http://localhost:5000/api/opportunities');
        if (!response.ok) {
          throw new Error('Failed to fetch opportunities');
        }
        const data = await response.json();
        setOpportunities(data);
        setFilteredOpportunities(data); // Initialize filtered list with all opportunities
      } catch (err) {
        console.error('Error fetching opportunities:', err);
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchOpportunities();
  }, []);

  // Apply filters whenever filters or opportunities change
  useEffect(() => {
    let result = opportunities;
    
    if (filters.category) {
      result = result.filter(opp => opp.title === filters.category);
    }
    
    if (filters.time) {
      result = result.filter(opp => opp.time === filters.time);
    }
    
    if (filters.location) {
      result = result.filter(opp => opp.location === filters.location);
    }
    
    setFilteredOpportunities(result);
  }, [filters, opportunities]);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const resetFilters = () => {
    setFilters({
      category: '',
      time: '',
      location: ''
    });
  };

  const handleOpportunityClick = (opportunity) => {
    // Map opportunity title to interest value
    let interestValue = '';
    switch(opportunity.title) {
      case 'Food Distribution Volunteer':
        interestValue = 'food';
        break;
      case 'Shelter Support Staff':
        interestValue = 'shelter';
        break;
      case 'Tutoring & Mentoring':
        interestValue = 'education';
        break;
      case 'Event Coordination':
        interestValue = 'events';
        break;
      default:
        interestValue = 'other';
    }

    setFormData(prev => ({
      ...prev,
      interest: interestValue,
      availability: `I'm interested in the ${opportunity.title} position (${opportunity.time}) at ${opportunity.location}.`
    }));

    // Scroll to form
    window.scrollTo({
      top: document.getElementById('volunteer-form').offsetTop - 100,
      behavior: 'smooth'
    });
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.agree) {
      setError('You must agree to the terms and conditions');
      return;
    }

    setIsLoading(true);
    setError(null);
    
    try {
      const response = await fetch('http://localhost:5000/api/volunteers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          firstName: formData.firstName.trim(),
          lastName: formData.lastName.trim(),
          email: formData.email.trim(),
          phone: formData.phone.trim(),
          interest: formData.interest,
          availability: formData.availability.trim(),
          experience: formData.experience.trim()
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Submission failed');
      }

      setSubmitted(true);
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        interest: '',
        availability: '',
        experience: '',
        agree: false
      });
    } catch (err) {
      console.error('Error submitting form:', err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-md text-center max-w-md">
          <h2 className="text-2xl font-bold mb-4 text-green-600">Thank You!</h2>
          <p className="text-gray-700 mb-6">
            Your volunteer application has been submitted successfully. 
            We'll review your information and contact you soon.
          </p>
          <button 
            onClick={() => setSubmitted(false)}
            className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition"
          >
            Submit Another Application
          </button>
        </div>
      </div>
    );
  }

  const testimonials = [
    {
      quote: "Volunteering with HopeForAll has been one of the most rewarding experiences of my life.",
      name: "Sarah Johnson",
      role: "Food Distribution Volunteer"
    },
    {
      quote: "The team is amazing and the work we do truly makes a difference in people's lives.",
      name: "Michael Chen",
      role: "Shelter Support"
    },
    {
      quote: "I love seeing the direct impact of my efforts in the community every week.",
      name: "David Rodriguez",
      role: "Tutoring Program"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-blue-700 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Volunteer With Us</h1>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join our team of dedicated volunteers and make a direct impact in your community.
          </p>
        </div>
      </section>

      {/* Volunteer Opportunities */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Current Opportunities</h2>
          
          {/* Filter Section */}
          <div className="mb-8 bg-gray-100 p-6 rounded-lg">
            <h3 className="text-xl font-semibold mb-4">Filter Opportunities</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label htmlFor="category" className="block text-gray-700 mb-2">Category</label>
                <select
                  id="category"
                  name="category"
                  value={filters.category}
                  onChange={handleFilterChange}
                  className="w-full px-4 py-2 border rounded-md"
                >
                  <option value="">All Categories</option>
                  {categories.map((category, index) => (
                    <option key={index} value={category}>{category}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="time" className="block text-gray-700 mb-2">Time</label>
                <select
                  id="time"
                  name="time"
                  value={filters.time}
                  onChange={handleFilterChange}
                  className="w-full px-4 py-2 border rounded-md"
                >
                  <option value="">All Times</option>
                  {times.map((time, index) => (
                    <option key={index} value={time}>{time}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="location" className="block text-gray-700 mb-2">Location</label>
                <select
                  id="location"
                  name="location"
                  value={filters.location}
                  onChange={handleFilterChange}
                  className="w-full px-4 py-2 border rounded-md"
                >
                  <option value="">All Locations</option>
                  {locations.map((location, index) => (
                    <option key={index} value={location}>{location}</option>
                  ))}
                </select>
              </div>
              <div className="flex items-end">
                <button
                  onClick={resetFilters}
                  className="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition"
                >
                  Reset Filters
                </button>
              </div>
            </div>
          </div>

          {isLoading ? (
            <div className="text-center">Loading opportunities...</div>
          ) : error ? (
            <div className="text-center text-red-500">{error}</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {filteredOpportunities.map((opp, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition">
                  <h3 className="text-xl font-semibold mb-2 text-blue-600">{opp.title}</h3>
                  <p className="text-gray-600 mb-4">{opp.desc}</p>
                  <div className="flex items-center text-gray-500 mb-2">
                    <span className="mr-2">🕒</span>
                    <span>{opp.time}</span>
                  </div>
                  <div className="flex items-center text-gray-500">
                    <span className="mr-2">📍</span>
                    <span>{opp.location}</span>
                  </div>
                  <button 
                    onClick={() => handleOpportunityClick(opp)}
                    className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition"
                  >
                    Apply Now
                  </button>
                </div>
              ))}
              {filteredOpportunities.length === 0 && (
                <div className="col-span-2 text-center py-8">
                  <p className="text-gray-600">No opportunities match your filters. Try adjusting your criteria.</p>
                </div>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Volunteer Form */}
      <section id="volunteer-form" className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-md">
            <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">Volunteer Application</h2>
            
            {error && <div className="mb-4 p-3 bg-red-100 text-red-700 rounded">{error}</div>}
            
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="firstName" className="block text-gray-700 mb-2">First Name *</label>
                  <input 
                    type="text" 
                    id="firstName" 
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    placeholder="Enter your first name"
                    className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="lastName" className="block text-gray-700 mb-2">Last Name *</label>
                  <input 
                    type="text" 
                    id="lastName" 
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleChange} 
                    placeholder="Enter your last name"
                    className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label htmlFor="email" className="block text-gray-700 mb-2">Email *</label>
                <input 
                  type="email" 
                  id="email" 
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Enter your email"
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-gray-700 mb-2">Phone *</label>
                <input 
                  type="tel" 
                  id="phone" 
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="Enter your phone number"
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label htmlFor="interest" className="block text-gray-700 mb-2">Area of Interest *</label>
                <select 
                  id="interest" 
                  name="interest"
                  value={formData.interest}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Select an option</option>
                  <option value="food">Food Distribution</option>
                  <option value="shelter">Shelter Support</option>
                  <option value="education">Education/Tutoring</option>
                  <option value="events">Event Coordination</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div>
                <label htmlFor="availability" className="block text-gray-700 mb-2">Availability *</label>
                <textarea 
                  id="availability" 
                  name="availability"
                  value={formData.availability}
                  onChange={handleChange}
                  rows="3"
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Please describe your weekly availability"
                  required
                />
              </div>

              <div>
                <label htmlFor="experience" className="block text-gray-700 mb-2">Relevant Experience</label>
                <textarea 
                  id="experience" 
                  name="experience"
                  value={formData.experience}
                  onChange={handleChange}
                  rows="3"
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Any previous volunteer or work experience that might be relevant"
                />
              </div>

              <div className="flex items-center">
                <input 
                  type="checkbox" 
                  id="agree" 
                  name="agree"
                  checked={formData.agree}
                  onChange={handleChange}
                  className="mr-2"
                  required
                />
                <label htmlFor="agree" className="text-gray-700">I agree to the terms and conditions *</label>
              </div>

              <button 
                type="submit" 
                disabled={isLoading}
                className={`w-full bg-blue-600 text-white px-6 py-3 rounded-md font-semibold hover:bg-blue-700 transition ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {isLoading ? 'Submitting...' : 'Submit Application'}
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">What Our Volunteers Say</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gray-100 p-6 rounded-lg">
                <p className="text-gray-700 italic mb-4">"{testimonial.quote}"</p>
                <div className="font-semibold">{testimonial.name}</div>
                <div className="text-gray-600 text-sm">{testimonial.role}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default VolunteerPage;