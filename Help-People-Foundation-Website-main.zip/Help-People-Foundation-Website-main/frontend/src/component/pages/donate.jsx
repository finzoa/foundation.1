import React, { useState } from 'react';

const DonatePage = () => {
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [donationAmount, setDonationAmount] = useState(0);
  const [donationFrequency, setDonationFrequency] = useState('one-time');
  const [paymentInfo, setPaymentInfo] = useState({
    email: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardholderName: '',
    country: 'Nepal'
  });
  const [isProcessing, setIsProcessing] = useState(false);
  const [donationSuccess, setDonationSuccess] = useState(false);

  const handleDonateClick = (amount) => {
    setDonationAmount(amount);
    setDonationFrequency('one-time');
    setShowPaymentModal(true);
  };

  const handleCustomDonation = (e) => {
    e.preventDefault();
    setShowPaymentModal(true);
  };

  const handlePaymentSubmit = async (e) => {
    e.preventDefault();
    setIsProcessing(true);

    // Extract month and year from expiry date
    const [expiryMonth, expiryYear] = paymentInfo.expiryDate.split(' / ');

    try {
      const response = await fetch('http://localhost:5000/api/donations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: donationAmount,
          frequency: donationFrequency,
          email: paymentInfo.email,
          cardInfo: {
            cardNumber: paymentInfo.cardNumber.replace(/\s/g, ''),
            expiryMonth: parseInt(expiryMonth),
            expiryYear: parseInt(expiryYear),
            cvv: paymentInfo.cvv
          },
          cardholderName: paymentInfo.cardholderName,
          country: paymentInfo.country
        }),
      });

      if (!response.ok) {
        throw new Error('Payment failed');
      }

      setDonationSuccess(true);
      setTimeout(() => {
        setShowPaymentModal(false);
        setDonationSuccess(false);
      }, 2000);
    } catch (error) {
      console.error('Payment error:', error);
      alert('Payment failed. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    
    // Format card number with spaces every 4 digits
    if (name === 'cardNumber') {
      const formattedValue = value.replace(/\s/g, '').replace(/(\d{4})/g, '$1 ').trim();
      setPaymentInfo(prev => ({ ...prev, [name]: formattedValue }));
      return;
    }
    
    setPaymentInfo(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full max-h-[90vh] overflow-y-auto">
            {donationSuccess ? (
              <div className="text-center py-8">
                <div className="text-5xl mb-4">🎉</div>
                <h3 className="text-2xl font-bold mb-2">Donation Successful!</h3>
                <p className="text-gray-600 mb-6">Thank you for your generous donation of Rs. {donationAmount}</p>
                <button
                  onClick={() => {
                    setShowPaymentModal(false);
                    setDonationSuccess(false);
                  }}
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition"
                >
                  Close
                </button>
              </div>
            ) : (
              <>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-bold">Complete Your Donation</h3>
                  <button 
                    onClick={() => setShowPaymentModal(false)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    ✕
                  </button>
                </div>
                
                <div className="mb-6 p-4 bg-gray-100 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-semibold">Donation Amount:</span>
                    <span className="font-bold">Rs. {donationAmount}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-semibold">Frequency:</span>
                    <span className="capitalize">{donationFrequency}</span>
                  </div>
                </div>

                <form onSubmit={handlePaymentSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="email" className="block text-gray-700 mb-1">Email</label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={paymentInfo.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="cardNumber" className="block text-gray-700 mb-1">Card Information</label>
                    <input
                      type="text"
                      id="cardNumber"
                      name="cardNumber"
                      value={paymentInfo.cardNumber}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="4242 4242 4242 4242"
                      maxLength="19"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="expiryDate" className="block text-gray-700 mb-1">Expiry Date</label>
                      <input
                        type="text"
                        id="expiryDate"
                        name="expiryDate"
                        value={paymentInfo.expiryDate}
                        onChange={(e) => {
                          // Format as MM / YY
                          let value = e.target.value.replace(/\D/g, '');
                          if (value.length > 2) {
                            value = value.slice(0, 2) + ' / ' + value.slice(2, 4);
                          }
                          setPaymentInfo(prev => ({ ...prev, expiryDate: value }));
                        }}
                        className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="MM / YY"
                        maxLength="7"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="cvv" className="block text-gray-700 mb-1">CVV</label>
                      <input
                        type="text"
                        id="cvv"
                        name="cvv"
                        value={paymentInfo.cvv}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="123"
                        maxLength="4"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="cardholderName" className="block text-gray-700 mb-1">Cardholder Name</label>
                    <input
                      type="text"
                      id="cardholderName"
                      name="cardholderName"
                      value={paymentInfo.cardholderName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="country" className="block text-gray-700 mb-1">Country or Region</label>
                    <select
                      id="country"
                      name="country"
                      value={paymentInfo.country}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    >
                      <option value="Nepal">Nepal</option>
                      <option value="India">India</option>
                      <option value="USA">United States</option>
                      <option value="UK">United Kingdom</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    disabled={isProcessing}
                    className="w-full bg-blue-600 text-white px-6 py-3 rounded-md font-semibold hover:bg-blue-700 transition disabled:opacity-70"
                  >
                    {isProcessing ? 'Processing...' : 'Pay'}
                  </button>
                </form>

                <p className="text-xs text-gray-500 mt-4">
                  Notwithstanding the logo displayed above, when paying with a co-branded elfpos debit card, 
                  your payment may be processed through either card network.
                </p>
              </>
            )}
          </div>
        </div>
      )}

      {/* Rest of your existing DonatePage component */}
      <section className="bg-blue-700 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Make a Difference Today</h1>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Your donation helps provide food, shelter, and hope to those who need it most.
          </p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Choose Your Donation</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              {[50, 100, 250].map((amount) => (
                <div key={amount} className="border-2 border-gray-200 rounded-lg p-6 text-center hover:border-blue-500 transition cursor-pointer">
                  <div className="text-3xl font-bold text-blue-600 mb-2">Rs. {amount}</div>
                  <p className="text-gray-600 mb-4">
                    {amount === 50 && 'Feeds a family for a week'}
                    {amount === 100 && 'Provides shelter for a night'}
                    {amount === 250 && 'Supports education for a month'}
                  </p>
                  <button 
                    onClick={() => handleDonateClick(amount)}
                    className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition w-full"
                  >
                    Donate Rs. {amount}
                  </button>
                </div>
              ))}
            </div>

            <div className="bg-gray-100 p-8 rounded-lg">
              <h3 className="text-2xl font-semibold mb-6 text-center">Or Give a Custom Amount</h3>
              <form onSubmit={handleCustomDonation} className="space-y-6">
                <div>
                  <label htmlFor="amount" className="block text-gray-700 mb-2">Donation Amount (Rs.)</label>
                  <input 
                    type="number" 
                    id="amount" 
                    className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter amount"
                    min="1"
                    value={donationAmount || ''}
                    onChange={(e) => setDonationAmount(parseInt(e.target.value) || 0)}
                    required
                  />
                </div>

                <div>
                  <label htmlFor="frequency" className="block text-gray-700 mb-2">Donation Frequency</label>
                  <select 
                    id="frequency" 
                    className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={donationFrequency}
                    onChange={(e) => setDonationFrequency(e.target.value)}
                  >
                    <option value="one-time">One-time donation</option>
                    <option value="monthly">Monthly donation</option>
                    <option value="quarterly">Quarterly donation</option>
                    <option value="yearly">Yearly donation</option>
                  </select>
                </div>

                <button 
                  type="submit" 
                  className="w-full bg-blue-600 text-white px-6 py-3 rounded-md font-semibold hover:bg-blue-700 transition"
                >
                  Continue to Payment
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">How Your Donation Helps</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {icon: '🍞', title: 'Food Security', desc: 'Provide nutritious meals to families facing hunger'},
              {icon: '🏠', title: 'Safe Shelter', desc: 'Offer warm beds and safety for homeless individuals'},
              {icon: '📚', title: 'Education', desc: 'Support children with school supplies and tuition'}
            ].map((item, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="text-4xl mb-4">{item.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default DonatePage;