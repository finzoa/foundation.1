import React, { useState, useMemo } from 'react';

const BlogPostCard = ({ post, onAddReview }) => {
  const [reviews, setReviews] = useState(post.reviews || []);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);

  const handleRatingSubmit = () => {
    if (rating === 0) return;
    
    console.log('Attempting to submit rating:', rating);
    const currentRating = rating;
    
    // Optimistically update UI
    const newReview = { rating: currentRating };
    setReviews([...reviews, newReview]);
    
    // Call parent handler
    onAddReview(post.id, currentRating);
    
    // Reset rating
    setRating(0);
  };

  const averageRating = useMemo(() => {
    if (!post.average_rating && reviews.length === 0) return 0;
    
    // Use server-provided average if available, otherwise calculate locally
    return post.average_rating || 
      reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length;
  }, [post.average_rating, reviews]);

  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition flex flex-col h-full">
      <img
        src={post.image_url}
        alt={post.title}
        className="w-full h-48 object-cover"
      />

      <div className="p-6 flex flex-col flex-grow">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-blue-600 font-semibold">{post.category}</span>
          <span className="text-sm text-gray-500">{post.date}</span>
        </div>

        <h3 className="text-xl font-semibold mb-3">{post.title}</h3>
        <p className="text-gray-600 mb-4">{post.description}</p>

        {/* Rating Section */}
        <div className="mt-auto">
          <div className="mb-4">
            <div className="flex items-center mb-1">
              <span className="font-medium text-gray-700 mr-2">
                {averageRating.toFixed(1)}
              </span>
              {[1, 2, 3, 4, 5].map((star) => (
                <span key={star} className="text-yellow-400">
                  {star <= Math.round(averageRating) ? '★' : '☆'}
                </span>
              ))}
              <span className="text-sm text-gray-500 ml-2">
                ({post.review_count || reviews.length} {post.review_count === 1 || reviews.length === 1 ? 'rating' : 'ratings'})
              </span>
            </div>

            <div className="flex items-center mt-2">
              <span className="text-sm text-gray-600 mr-2">Your rating:</span>
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  className="text-2xl focus:outline-none"
                  onClick={() => {
                    console.log('Star clicked:', star);
                    setRating(star);
                  }}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                >
                  <span className={star <= (hoverRating || rating) ? 'text-yellow-400' : 'text-gray-300'}>
                    {star <= (hoverRating || rating) ? '★' : '☆'}
                  </span>
                </button>
              ))}

              <button
                onClick={handleRatingSubmit}
                disabled={rating === 0}
                className={`ml-4 px-3 py-1 text-sm rounded transition ${
                  rating === 0 
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogPostCard;