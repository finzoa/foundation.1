import React, { useState, useEffect } from "react";
import { BrowserRouter } from "react-router-dom";
import AppRoutes from "./routes";
import './App.css';
import Navbar from "./component/navbar/navbar";
import Footer from "./component/footer/footer";

function App() {
  const [user, setUser] = useState(null);

  // Update user data when localStorage changes
  useEffect(() => {
    const updateUser = () => {
      const user_firstname = localStorage.getItem("firstname");
      const user_lastname = localStorage.getItem("lastname");
      const user_email = localStorage.getItem("email");
      
      if (user_firstname && user_lastname) {
        setUser({
          name: `${user_firstname} ${user_lastname}`,
          email: user_email
        });
      } else {
        setUser(null);
      }
    };

    // Call initially
    updateUser();

    // Listen for storage events (changes from other tabs)
    window.addEventListener('storage', updateUser);

    return () => {
      window.removeEventListener('storage', updateUser);
    };
  }, []);

  return (
    <BrowserRouter>
      <Navbar user={user} />
      <AppRoutes />
      <Footer />
    </BrowserRouter>  
  );
}

export default App;