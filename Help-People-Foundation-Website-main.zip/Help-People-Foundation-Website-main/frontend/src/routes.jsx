// File: frontend/src/route.jsx
import React from "react";
import { Routes, Route } from "react-router-dom";
import Homepage from "./component/pages/homepage";
import About from "./component/pages/aboutus";
import Contact from "./component/pages/contact";
import Donate from "./component/pages/donate";
import Blog from "./component/pages/blog";
import Volunteer from "./component/pages/volunteer";
import Login from "./component/authentication/login";
import Signup from "./component/authentication/signup";
import ProfilePage from "./component/pages/profile";
import Settings from "./component/pages/settings";

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Homepage />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/donate" element={<Donate />} />
      <Route path="/blog" element={<Blog />} />
      <Route path="/volunteer" element={<Volunteer />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/profile" element={<ProfilePage />} />
      <Route path="/settings" element={<Settings />} />
      {/* Add more routes as needed */}

    </Routes>
  );
};

export default AppRoutes;
